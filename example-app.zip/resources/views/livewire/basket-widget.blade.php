<div class="indicator cursor-pointer p-0 mr-3">
    <span class="indicator-item badge badge-secondary cursor-pointer border-white bg-white text-[#4C71FB] font-bold font-mono">{{ basket()->count() }}</span>
    <label for="my-drawer-3" aria-label="open sidebar" class="cursor-pointer max-sm:px-2 px-4 py-2">
        <i class="ri-shopping-basket-2-line cursor-pointer text-2xl text-white"></i>
    </label>
</div>
