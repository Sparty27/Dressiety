<meta name="title" content="{{ $title }}">
<meta name="description" content="{{ $description }}">

<meta name="og:title" content="{{ $title }}">
<meta name="og:description" content="{{ $description }}">

<meta name="twitter:title" content="{{ $title }}">
<meta name="twitter:description" content="{{ $description }}">
