<div class="card card-compact bg-base-100 shadow-xl {{ $class ?? '' }}">
    <div class="card-body">
        {{ $slot }}
    </div>
</div>
