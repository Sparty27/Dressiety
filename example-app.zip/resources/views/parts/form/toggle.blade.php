<div class="form-control">
    <label class="label cursor-pointer">
        <span class="label-text">{{ $title }}</span>
        <input type="checkbox" class="toggle" wire:model="{{ $model }}"/>
    </label>
</div>
